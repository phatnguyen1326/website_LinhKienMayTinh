<template>
  <nav class="bg-[#0D0F12] border-b border-[rgba(255,255,255,0.08)] sticky top-0 z-40">
    <div class="max-w-7xl mx-auto px-4 py-4">
      <div class="flex items-center justify-between gap-6">
        <!-- Logo -->
        <div class="flex items-center gap-2 flex-shrink-0 min-w-max">
          <div class="bg-gradient-to-br from-[#2563EB] to-[#06B6D4] p-2 rounded-lg">
            <IconCPU :size="24" class="text-white" />
          </div>
          <span class="text-xl font-bold text-[#F1F5F9]">TechZone</span>
        </div>

        <!-- Search Bar -->
        <div class="flex-1 max-w-md">
          <div class="relative">
            <input
              type="text"
              placeholder="Tìm RAM, CPU, VGA..."
              class="w-full bg-[#1E2228] border border-[rgba(255,255,255,0.08)] rounded-lg px-4 py-2.5 pl-10 text-[#F1F5F9] placeholder-[#64748B] focus:outline-none focus:border-[#2563EB] focus:shadow-[0_0_12px_rgba(37,99,235,0.3)] transition-all"
            />
            <IconSearch :size="18" class="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
          </div>
        </div>

        <!-- Right Icons -->
        <div class="flex items-center gap-4 flex-shrink-0">
          <!-- Compare -->
          <button
            class="relative p-2 text-[#94A3B8] hover:text-[#06B6D4] transition-colors group"
            title="So sánh sản phẩm"
          >
            <IconCompare :size="20" />
            <span class="absolute top-0 right-0 w-5 h-5 bg-[#06B6D4] text-[#0D0F12] text-xs rounded-full flex items-center justify-center font-bold opacity-0 group-hover:opacity-100 transition-opacity">
              0
            </span>
          </button>

          <!-- Cart -->
          <button
            class="relative p-2 text-[#94A3B8] hover:text-[#2563EB] transition-colors group"
            title="Giỏ hàng"
          >
            <IconCart :size="20" />
            <span class="absolute -top-2 -right-2 w-5 h-5 bg-[#EF4444] text-white text-xs rounded-full flex items-center justify-center font-bold opacity-0 group-hover:opacity-100 transition-opacity">
              0
            </span>
          </button>

          <!-- User -->
          <button
            class="p-2 text-[#94A3B8] hover:text-[#F1F5F9] transition-colors"
            title="Tài khoản"
          >
            <IconUser :size="20" />
          </button>
        </div>
      </div>
    </div>
  </nav>
</template>

<script setup lang="ts">
import IconCPU from '~/components/icons/IconCPU.vue'
import IconSearch from '~/components/icons/IconSearch.vue'
import IconCompare from '~/components/icons/IconCompare.vue'
import IconCart from '~/components/icons/IconCart.vue'
import IconUser from '~/components/icons/IconUser.vue'
</script>
