<template>
  <footer class="bg-[#0D0F12] border-t border-[rgba(255,255,255,0.08)] mt-20">
    <div class="max-w-7xl mx-auto px-4 py-12">
      <!-- Main Footer Content -->
      <div class="grid grid-cols-4 gap-12 mb-12">
        <!-- About -->
        <div>
          <div class="flex items-center gap-2 mb-6">
            <div class="bg-gradient-to-br from-[#2563EB] to-[#06B6D4] p-2 rounded-lg">
              <IconCPU :size="20" class="text-white" />
            </div>
            <span class="text-lg font-bold text-[#F1F5F9]">TechZone</span>
          </div>
          <p class="text-[#94A3B8] text-sm leading-relaxed">
            Cung cấp các linh kiện PC chất lượng cao với giá cạnh tranh và dịch vụ tốt nhất.
          </p>
        </div>

        <!-- Categories -->
        <div>
          <h3 class="text-[#F1F5F9] font-semibold mb-4">Danh Mục</h3>
          <ul class="space-y-3">
            <li>
              <a href="#" class="text-[#94A3B8] hover:text-[#06B6D4] transition-colors text-sm">
                RAM
              </a>
            </li>
            <li>
              <a href="#" class="text-[#94A3B8] hover:text-[#06B6D4] transition-colors text-sm">
                CPU
              </a>
            </li>
            <li>
              <a href="#" class="text-[#94A3B8] hover:text-[#06B6D4] transition-colors text-sm">
                VGA
              </a>
            </li>
            <li>
              <a href="#" class="text-[#94A3B8] hover:text-[#06B6D4] transition-colors text-sm">
                Mainboard
              </a>
            </li>
            <li>
              <a href="#" class="text-[#94A3B8] hover:text-[#06B6D4] transition-colors text-sm">
                Nguồn
              </a>
            </li>
            <li>
              <a href="#" class="text-[#94A3B8] hover:text-[#06B6D4] transition-colors text-sm">
                Case
              </a>
            </li>
          </ul>
        </div>

        <!-- Support -->
        <div>
          <h3 class="text-[#F1F5F9] font-semibold mb-4">Hỗ Trợ</h3>
          <ul class="space-y-3">
            <li>
              <a href="#" class="text-[#94A3B8] hover:text-[#06B6D4] transition-colors text-sm">
                Liên hệ
              </a>
            </li>
            <li>
              <a href="#" class="text-[#94A3B8] hover:text-[#06B6D4] transition-colors text-sm">
                FAQs
              </a>
            </li>
            <li>
              <a href="#" class="text-[#94A3B8] hover:text-[#06B6D4] transition-colors text-sm">
                Chính sách trả hàng
              </a>
            </li>
            <li>
              <a href="#" class="text-[#94A3B8] hover:text-[#06B6D4] transition-colors text-sm">
                Điều khoản sử dụng
              </a>
            </li>
            <li>
              <a href="#" class="text-[#94A3B8] hover:text-[#06B6D4] transition-colors text-sm">
                Bảo mật
              </a>
            </li>
          </ul>
        </div>

        <!-- Payment Methods -->
        <div>
          <h3 class="text-[#F1F5F9] font-semibold mb-4">Thanh Toán</h3>
          <div class="flex flex-wrap gap-3">
            <div class="bg-[#1E2228] border border-[rgba(255,255,255,0.08)] rounded-lg px-3 py-2">
              <span class="text-xs font-bold text-[#06B6D4]">VISA</span>
            </div>
            <div class="bg-[#1E2228] border border-[rgba(255,255,255,0.08)] rounded-lg px-3 py-2">
              <span class="text-xs font-bold text-[#EF4444]">MoMo</span>
            </div>
            <div class="bg-[#1E2228] border border-[rgba(255,255,255,0.08)] rounded-lg px-3 py-2">
              <span class="text-xs font-bold text-[#22C55E]">VNPAY</span>
            </div>
            <div class="bg-[#1E2228] border border-[rgba(255,255,255,0.08)] rounded-lg px-3 py-2">
              <span class="text-xs font-bold text-[#2563EB]">PayPal</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Social Links & Bottom -->
      <div class="border-t border-[rgba(255,255,255,0.08)] pt-8">
        <div class="flex items-center justify-between">
          <p class="text-[#64748B] text-sm">
            © 2024 TechZone. All rights reserved.
          </p>
          <div class="flex items-center gap-4">
            <a
              href="#"
              class="text-[#94A3B8] hover:text-[#06B6D4] transition-colors text-sm"
            >
              Facebook
            </a>
            <a
              href="#"
              class="text-[#94A3B8] hover:text-[#06B6D4] transition-colors text-sm"
            >
              Twitter
            </a>
            <a
              href="#"
              class="text-[#94A3B8] hover:text-[#06B6D4] transition-colors text-sm"
            >
              Instagram
            </a>
            <a
              href="#"
              class="text-[#94A3B8] hover:text-[#06B6D4] transition-colors text-sm"
            >
              YouTube
            </a>
          </div>
        </div>
      </div>
    </div>
  </footer>
</template>

<script setup lang="ts">
import IconCPU from '~/components/icons/IconCPU.vue'
</script>
