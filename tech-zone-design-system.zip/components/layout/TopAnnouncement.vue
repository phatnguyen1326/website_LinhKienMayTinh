<template>
  <div
    v-if="!dismissed"
    class="bg-[#1E2228] border-b border-[rgba(255,255,255,0.08)] px-4 py-3"
  >
    <div class="max-w-7xl mx-auto flex items-center justify-between text-sm">
      <div class="flex-1 text-center text-[#94A3B8]">
        <span class="text-[#06B6D4]">★ Miễn phí vận chuyển cho đơn hàng trên 500K</span>
        <span class="mx-4">|</span>
        <span>Hotline: 1800-xxxx</span>
      </div>
      <button
        @click="dismissed = true"
        class="ml-4 text-[#94A3B8] hover:text-[#F1F5F9] transition-colors"
      >
        ✕
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
const dismissed = ref(false)

onMounted(() => {
  dismissed.value = localStorage.getItem('announcement_dismissed') === 'true'
})

watch(dismissed, (newVal) => {
  localStorage.setItem('announcement_dismissed', String(newVal))
})
</script>
