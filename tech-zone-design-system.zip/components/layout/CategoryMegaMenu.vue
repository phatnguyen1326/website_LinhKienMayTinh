<template>
  <nav class="bg-[#0D0F12] border-b border-[rgba(255,255,255,0.08)]">
    <div class="max-w-7xl mx-auto px-4">
      <div class="flex items-center gap-8">
        <div
          v-for="category in categories"
          :key="category.id"
          class="group relative"
        >
          <!-- Main Category Button -->
          <button
            class="py-4 px-2 flex items-center gap-2 text-[#94A3B8] hover:text-[#06B6D4] transition-colors font-medium text-sm"
          >
            <span>{{ category.name }}</span>
            <IconChevronDown :size="16" class="group-hover:rotate-180 transition-transform" />
          </button>

          <!-- Mega Menu Dropdown -->
          <div
            class="absolute left-0 top-full hidden group-hover:block bg-[#161A1F] border border-[rgba(255,255,255,0.08)] rounded-lg shadow-2xl shadow-black/50 pt-2 pb-4 min-w-80 z-50"
          >
            <div class="grid grid-cols-2 gap-6 px-6 py-4">
              <div v-for="subcategory in category.subcategories" :key="subcategory">
                <a
                  href="#"
                  class="block text-[#F1F5F9] hover:text-[#2563EB] transition-colors text-sm font-medium hover:translate-x-1 transition-transform"
                >
                  {{ subcategory }}
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </nav>
</template>

<script setup lang="ts">
import IconChevronDown from '~/components/icons/IconChevronDown.vue'

interface Category {
  id: string
  name: string
  subcategories: string[]
}

const categories: Category[] = [
  {
    id: 'ram',
    name: 'RAM',
    subcategories: [
      'DDR5 16GB',
      'DDR5 32GB',
      'DDR5 64GB',
      'DDR4 16GB',
      'DDR4 32GB',
      'Corsair',
      'G.Skill',
      'Kingston',
    ],
  },
  {
    id: 'cpu',
    name: 'CPU',
    subcategories: [
      'Intel Core i9',
      'Intel Core i7',
      'Intel Core i5',
      'AMD Ryzen 9',
      'AMD Ryzen 7',
      'AMD Ryzen 5',
    ],
  },
  {
    id: 'vga',
    name: 'VGA',
    subcategories: [
      'NVIDIA RTX 4090',
      'NVIDIA RTX 4080',
      'NVIDIA RTX 4070',
      'AMD RX 7900 XTX',
      'AMD RX 7900 XT',
      'Entry Level',
    ],
  },
  {
    id: 'mainboard',
    name: 'Mainboard',
    subcategories: [
      'Intel LGA 1700',
      'Intel LGA 1200',
      'AMD AM5',
      'AMD AM4',
      'Z890',
      'B850',
    ],
  },
  {
    id: 'psu',
    name: 'Nguồn',
    subcategories: [
      '1000W+',
      '750W - 1000W',
      '600W - 750W',
      'Modular',
      'Semi Modular',
      'Non Modular',
    ],
  },
  {
    id: 'case',
    name: 'Case',
    subcategories: [
      'Mid Tower',
      'Full Tower',
      'Mini ITX',
      'RGB Case',
      'Compact Case',
      'Gaming Case',
    ],
  },
]
</script>
