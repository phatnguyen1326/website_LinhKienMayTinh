<template>
  <div class="fixed bottom-6 right-6 z-40">
    <!-- Chat Widget -->
    <div 
      v-if="isOpen"
      class="bg-[#161A1F] border border-[rgba(255,255,255,0.08)] rounded-lg shadow-lg shadow-blue-500/20 w-80 h-96 flex flex-col"
    >
      <!-- Header -->
      <div class="bg-gradient-to-r from-[#2563EB] to-[#06B6D4] px-4 py-3 flex items-center justify-between rounded-t-lg">
        <div class="flex items-center gap-2">
          <div class="w-2 h-2 bg-[#22C55E] rounded-full animate-pulse"></div>
          <h3 class="text-white font-semibold text-sm">TechBot AI</h3>
        </div>
        <button 
          @click="isOpen = false"
          class="text-white hover:opacity-70 transition"
        >
          ✕
        </button>
      </div>

      <!-- Messages -->
      <div class="flex-1 overflow-y-auto p-4 space-y-3">
        <div 
          v-for="message in messages"
          :key="message.id"
          class="flex"
          :class="message.sender === 'user' ? 'justify-end' : 'justify-start'"
        >
          <div 
            class="max-w-xs px-3 py-2 rounded-lg text-sm"
            :class="message.sender === 'user' 
              ? 'bg-[#2563EB] text-white rounded-br-none' 
              : 'bg-[#1E2228] text-[#94A3B8] rounded-bl-none'"
          >
            {{ message.text }}
          </div>
        </div>
      </div>

      <!-- Quick Questions -->
      <div v-if="messages.length === 0" class="px-4 py-3 space-y-2 border-t border-[rgba(255,255,255,0.08)]">
        <p class="text-[#94A3B8] text-xs font-semibold mb-2">Câu hỏi nhanh:</p>
        <button
          v-for="question in quickQuestions"
          :key="question"
          @click="sendMessage(question)"
          class="w-full text-left text-xs bg-[#1E2228] text-[#06B6D4] px-2 py-1.5 rounded hover:bg-[#2563EB]/20 transition"
        >
          {{ question }}
        </button>
      </div>

      <!-- Input -->
      <div class="border-t border-[rgba(255,255,255,0.08)] px-4 py-3">
        <div class="flex gap-2">
          <input
            v-model="inputMessage"
            @keyup.enter="sendMessage(inputMessage)"
            type="text"
            placeholder="Nhập câu hỏi..."
            class="flex-1 bg-[#1E2228] border border-[rgba(255,255,255,0.08)] rounded px-2 py-1.5 text-[#F1F5F9] text-sm focus:outline-none focus:border-[#2563EB] placeholder-[#94A3B8]"
          />
          <button
            @click="sendMessage(inputMessage)"
            class="bg-[#2563EB] text-white px-3 py-1.5 rounded hover:bg-[#3B82F6] transition"
          >
            →
          </button>
        </div>
        <p class="text-[#94A3B8] text-xs mt-2 text-center">
          Powered by Gemini AI
        </p>
      </div>
    </div>

    <!-- Toggle Button -->
    <button
      v-else
      @click="isOpen = true"
      class="bg-gradient-to-r from-[#2563EB] to-[#06B6D4] text-white rounded-full w-14 h-14 flex items-center justify-center shadow-lg shadow-blue-500/50 hover:shadow-lg hover:shadow-blue-500/70 transition"
    >
      💬
    </button>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

interface ChatMessage {
  id: string
  text: string
  sender: 'user' | 'bot'
}

const isOpen = ref(false)
const messages = ref<ChatMessage[]>([])
const inputMessage = ref('')

const quickQuestions = [
  'Sản phẩm này có bảo hành không?',
  'Thời gian giao hàng là bao lâu?',
  'Có phương thức thanh toán nào?',
  'Sản phẩm này phù hợp với cấu hình nào?',
]

const sendMessage = async (text: string) => {
  if (!text.trim()) return

  // Add user message
  messages.value.push({
    id: `msg-${Date.now()}`,
    text,
    sender: 'user',
  })

  inputMessage.value = ''

  // Simulate bot response
  setTimeout(() => {
    messages.value.push({
      id: `msg-${Date.now()}`,
      text: 'Cảm ơn bạn! Tôi là TechBot AI, sẵn sàng hỗ trợ bạn. Bạn có câu hỏi gì về sản phẩm này không?',
      sender: 'bot',
    })
  }, 500)
}
</script>
