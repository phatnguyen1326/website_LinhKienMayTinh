<template>
  <div class="space-y-4">
    <!-- Product Gallery -->
    <div>
      <div class="bg-[#161A1F] rounded-lg overflow-hidden mb-4 h-96">
        <img 
          :src="currentImage" 
          :alt="product.name"
          class="w-full h-full object-cover"
        />
      </div>

      <!-- Thumbnails -->
      <div class="flex gap-2 overflow-x-auto">
        <button
          v-for="(image, index) in product.gallery"
          :key="index"
          @click="currentImage = image"
          class="flex-shrink-0 w-16 h-16 rounded border-2 overflow-hidden"
          :class="currentImage === image ? 'border-[#2563EB]' : 'border-[rgba(255,255,255,0.08)]'"
        >
          <img :src="image" :alt="`Thumbnail ${index + 1}`" class="w-full h-full object-cover" />
        </button>
      </div>
    </div>

    <!-- Badges -->
    <div v-if="product.badges.length > 0" class="flex gap-2 flex-wrap">
      <span v-for="badge in product.badges" :key="badge" class="badge-secondary">
        {{ badge }}
      </span>
    </div>

    <!-- Stock Status -->
    <div class="bg-[#161A1F] rounded-lg p-3">
      <p v-if="product.stock > 0" class="text-[#22C55E] text-sm font-medium">
        ✓ Còn {{ product.stock }} sản phẩm
      </p>
      <p v-else class="text-[#EF4444] text-sm font-medium">
        ✕ Hết hàng
      </p>
    </div>

    <!-- Warranty -->
    <div class="bg-[#161A1F] rounded-lg p-3">
      <p class="text-[#94A3B8] text-sm">
        <span class="text-[#F1F5F9] font-semibold">Bảo hành:</span> {{ product.warranty }}
      </p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import type { Product } from '~/stores/product'

interface Props {
  product: Product
}

defineProps<Props>()

const currentImage = ref<string>()

watch(() => props.product, (newProduct) => {
  currentImage.value = newProduct.gallery[0] || newProduct.image
}, { immediate: true, deep: true })
</script>
