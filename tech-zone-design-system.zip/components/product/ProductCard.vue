<template>
  <div class="card-hover cursor-pointer group h-full flex flex-col" @click="navigateToProduct">
    <!-- Product Image -->
    <div class="relative mb-3 overflow-hidden rounded-lg bg-[#1E2228] h-48">
      <img 
        :src="product.image" 
        :alt="product.name"
        class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
      />
      
      <!-- Badges -->
      <div class="absolute top-2 right-2 flex flex-col gap-2">
        <span 
          v-for="badge in product.badges" 
          :key="badge"
          class="badge-secondary text-xs"
        >
          {{ badge }}
        </span>
      </div>

      <!-- Stock Status -->
      <div v-if="product.stock === 0" class="absolute inset-0 bg-black/50 flex items-center justify-center">
        <span class="text-[#EF4444] font-bold">Hết Hàng</span>
      </div>
    </div>

    <!-- Product Info -->
    <div class="flex-1 flex flex-col">
      <!-- Brand and Rating -->
      <div class="flex items-center justify-between mb-2">
        <span class="text-[#06B6D4] text-sm font-medium">{{ product.brand }}</span>
        <div class="flex items-center gap-1">
          <span class="text-yellow-400">★</span>
          <span class="text-[#94A3B8] text-xs">{{ product.rating }} ({{ product.reviews }})</span>
        </div>
      </div>

      <!-- Product Name -->
      <h3 class="text-[#F1F5F9] font-semibold text-sm mb-2 line-clamp-2 group-hover:text-[#2563EB] transition-colors">
        {{ product.name }}
      </h3>

      <!-- Price -->
      <div class="mb-3">
        <div class="flex items-center gap-2 mb-1">
          <span class="text-[#2563EB] font-bold text-lg">
            {{ formatPrice(product.price) }}
          </span>
          <span v-if="product.originalPrice > product.price" class="text-[#94A3B8] line-through text-sm">
            {{ formatPrice(product.originalPrice) }}
          </span>
        </div>
        <div v-if="product.discount > 0" class="flex items-center gap-1">
          <span class="badge-sale text-xs">
            -{{ product.discount }}%
          </span>
          <span class="text-[#94A3B8] text-xs">Tiết kiệm {{ formatPrice(product.originalPrice - product.price) }}</span>
        </div>
      </div>

      <!-- Specs Preview -->
      <div v-if="specs.length > 0" class="mb-3 text-xs text-[#94A3B8]">
        <div v-for="spec in specs" :key="spec" class="line-clamp-1">
          • {{ spec }}
        </div>
      </div>

      <!-- Action Buttons -->
      <div class="mt-auto flex gap-2">
        <button 
          @click.stop="addToCart"
          :disabled="product.stock === 0"
          class="flex-1 btn-primary text-sm disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Thêm Giỏ
        </button>
        <button 
          @click.stop="toggleCompare"
          class="btn-secondary px-3 text-sm"
          :class="{ 'border-[#06B6D4]': isCompared }"
        >
          So Sánh
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue'
import type { Product } from '~/stores/product'
import { useCartStore } from '~/stores/cart'

interface Props {
  product: Product
}

const props = defineProps<Props>()
const emit = defineEmits<{
  compare: [productId: string]
}>()

const cartStore = useCartStore()
const isCompared = ref(false)

const specs = computed(() => {
  return Object.values(props.product.specs).slice(0, 2)
})

const formatPrice = (price: number) => {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
  }).format(price)
}

const navigateToProduct = () => {
  navigateTo(`/san-pham/${props.product.slug}`)
}

const addToCart = () => {
  cartStore.addItem({
    id: `${props.product.id}-${Date.now()}`,
    productId: props.product.id,
    name: props.product.name,
    price: props.product.price,
    quantity: 1,
    image: props.product.image,
  })
}

const toggleCompare = () => {
  isCompared.value = !isCompared.value
  emit('compare', props.product.id)
}
</script>
