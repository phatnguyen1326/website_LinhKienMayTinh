<template>
  <div class="bg-[#161A1F] rounded-lg overflow-hidden">
    <table class="w-full text-sm">
      <tbody>
        <tr 
          v-for="(value, key, index) in product.specs"
          :key="key"
          class="border-b border-[rgba(255,255,255,0.08)]"
          :class="index % 2 === 0 ? 'bg-[#0D0F12]' : 'bg-[#161A1F]'"
        >
          <td class="px-4 py-3 text-[#94A3B8] font-medium w-1/3">{{ key }}</td>
          <td class="px-4 py-3 text-[#F1F5F9]">{{ value }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup lang="ts">
import type { Product } from '~/stores/product'

interface Props {
  product: Product
}

defineProps<Props>()
</script>
