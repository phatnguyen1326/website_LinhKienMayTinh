<template>
  <div class="space-y-6">
    <!-- Search -->
    <div class="relative">
      <IconSearch class="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" :size="20" />
      <input
        v-model="searchQuery"
        type="text"
        placeholder="Tìm sản phẩm..."
        class="w-full bg-[#161A1F] border border-[rgba(255,255,255,0.08)] rounded-lg pl-10 pr-4 py-2 text-[#F1F5F9] placeholder-[#94A3B8] focus:outline-none focus:border-[#2563EB]"
      />
    </div>

    <!-- Categories -->
    <div>
      <h3 class="text-[#F1F5F9] font-semibold mb-3 text-sm">Danh Mục</h3>
      <div class="space-y-2">
        <label 
          v-for="category in categories"
          :key="category"
          class="flex items-center gap-2 cursor-pointer"
        >
          <input
            type="radio"
            :value="category"
            v-model="selectedCategory"
            class="w-4 h-4 accent-[#2563EB]"
          />
          <span class="text-[#94A3B8] text-sm hover:text-[#F1F5F9]">{{ category }}</span>
        </label>
        <label class="flex items-center gap-2 cursor-pointer">
          <input
            type="radio"
            :value="null"
            v-model="selectedCategory"
            class="w-4 h-4 accent-[#2563EB]"
          />
          <span class="text-[#94A3B8] text-sm hover:text-[#F1F5F9]">Tất cả</span>
        </label>
      </div>
    </div>

    <!-- Brands -->
    <div>
      <h3 class="text-[#F1F5F9] font-semibold mb-3 text-sm">Thương Hiệu</h3>
      <div class="space-y-2 max-h-40 overflow-y-auto">
        <label 
          v-for="brand in brands"
          :key="brand"
          class="flex items-center gap-2 cursor-pointer"
        >
          <input
            type="checkbox"
            :value="brand"
            v-model="selectedBrand"
            class="w-4 h-4 accent-[#2563EB]"
          />
          <span class="text-[#94A3B8] text-sm hover:text-[#F1F5F9]">{{ brand }}</span>
        </label>
      </div>
    </div>

    <!-- Price Range -->
    <div>
      <h3 class="text-[#F1F5F9] font-semibold mb-3 text-sm">Giá</h3>
      <div class="space-y-2">
        <div class="flex gap-2">
          <input
            v-model.number="priceMin"
            type="number"
            placeholder="Từ"
            class="flex-1 bg-[#161A1F] border border-[rgba(255,255,255,0.08)] rounded px-2 py-1 text-[#F1F5F9] text-sm"
          />
          <input
            v-model.number="priceMax"
            type="number"
            placeholder="Đến"
            class="flex-1 bg-[#161A1F] border border-[rgba(255,255,255,0.08)] rounded px-2 py-1 text-[#F1F5F9] text-sm"
          />
        </div>
      </div>
    </div>

    <!-- Stock Status -->
    <div>
      <h3 class="text-[#F1F5F9] font-semibold mb-3 text-sm">Tình Trạng</h3>
      <label class="flex items-center gap-2 cursor-pointer">
        <input
          type="checkbox"
          v-model="inStockOnly"
          class="w-4 h-4 accent-[#2563EB]"
        />
        <span class="text-[#94A3B8] text-sm hover:text-[#F1F5F9]">Chỉ sản phẩm còn hàng</span>
      </label>
    </div>

    <!-- Clear Filters -->
    <button
      @click="clearAllFilters"
      class="w-full btn-secondary text-sm"
    >
      Xóa Tất Cả Bộ Lọc
    </button>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useProductStore } from '~/stores/product'

const productStore = useProductStore()

const searchQuery = computed({
  get: () => productStore.filters.searchQuery || '',
  set: (value: string) => productStore.setFilter({ searchQuery: value || undefined }),
})

const selectedCategory = computed({
  get: () => productStore.filters.category || null,
  set: (value: string | null) => productStore.setFilter({ category: value || undefined }),
})

const selectedBrand = computed({
  get: () => (productStore.filters.brand ? [productStore.filters.brand] : []),
  set: (value: string[]) => productStore.setFilter({ brand: value[0] || undefined }),
})

const priceMin = computed({
  get: () => productStore.filters.priceMin || undefined,
  set: (value: number | undefined) => productStore.setFilter({ priceMin: value }),
})

const priceMax = computed({
  get: () => productStore.filters.priceMax || undefined,
  set: (value: number | undefined) => productStore.setFilter({ priceMax: value }),
})

const inStockOnly = computed({
  get: () => productStore.filters.inStock || false,
  set: (value: boolean) => productStore.setFilter({ inStock: value || undefined }),
})

const categories = computed(() => productStore.categories)
const brands = computed(() => productStore.brands)

const clearAllFilters = () => {
  productStore.clearFilters()
}
</script>
