<template>
  <section class="bg-[#0D0F12] py-12">
    <div class="max-w-7xl mx-auto px-4">
      <h2 class="text-3xl font-bold text-[#F1F5F9] mb-8 pb-4 border-b border-[rgba(255,255,255,0.08)]">
        <span class="relative">
          Sản Phẩm Nổi Bật
          <div class="absolute bottom-0 left-0 w-24 h-1 bg-gradient-to-r from-[#2563EB] to-[#06B6D4]" />
        </span>
      </h2>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div
          v-for="product in featuredProducts"
          :key="product.id"
          class="card-hover group flex flex-col"
        >
          <!-- Product image area -->
          <div class="h-48 bg-gradient-to-br from-[#1E2228] to-[#0D0F12] rounded-lg mb-4 flex items-center justify-center overflow-hidden">
            <div class="text-5xl group-hover:scale-110 transition-transform duration-300">
              {{ product.icon }}
            </div>
          </div>

          <!-- Badge -->
          <div class="mb-2">
            <span v-if="product.badge === 'NEW'" class="badge-secondary">
              ✨ NEW
            </span>
            <span v-else-if="product.badge === 'HOT'" class="badge-sale">
              🔥 HOT
            </span>
            <span v-else-if="product.badge === 'SALE'" class="badge-sale">
              🎉 SALE -{{ product.discount }}%
            </span>
          </div>

          <!-- Product name -->
          <h3 class="font-semibold text-[#F1F5F9] mb-2 line-clamp-2">{{ product.name }}</h3>

          <!-- Specs -->
          <p class="text-xs text-[#94A3B8] mb-4 line-clamp-2">{{ product.specs }}</p>

          <!-- Pricing -->
          <div class="mb-4 flex-grow">
            <p v-if="product.originalPrice" class="text-sm text-[#94A3B8] line-through">
              {{ product.originalPrice.toLocaleString('vi-VN') }}₫
            </p>
            <p class="text-lg font-bold text-[#2563EB]">
              {{ product.price.toLocaleString('vi-VN') }}₫
            </p>
          </div>

          <!-- Installment text -->
          <p class="text-xs text-[#06B6D4] mb-4">Trả góp 0%</p>

          <!-- Actions -->
          <div class="flex gap-2">
            <button class="flex-1 btn-primary text-sm">
              Thêm vào giỏ
            </button>
            <button class="px-3 py-2 border border-[rgba(255,255,255,0.1)] rounded-lg text-[#F1F5F9] hover:border-[#2563EB] transition-colors hover:bg-[#2563EB]/10">
              ⚖️
            </button>
            <button class="px-3 py-2 border border-[rgba(255,255,255,0.1)] rounded-lg text-[#F1F5F9] hover:border-[#EF4444] transition-colors hover:bg-[#EF4444]/10">
              ❤️
            </button>
          </div>
        </div>
      </div>

      <!-- View all button -->
      <div class="text-center mt-8">
        <button class="btn-secondary px-8 py-3">
          Xem tất cả sản phẩm →
        </button>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
const featuredProducts = [
  {
    id: 1,
    name: 'Intel Core i9-14900K',
    specs: '24 nhân | LGA1700 | 125W',
    price: 17990000,
    originalPrice: 24990000,
    badge: 'HOT',
    discount: 28,
    icon: '⚙️',
  },
  {
    id: 2,
    name: 'AMD Ryzen 7 7700X',
    specs: '8 nhân | AM5 | 105W',
    price: 8990000,
    originalPrice: 12990000,
    badge: 'SALE',
    discount: 31,
    icon: '⚙️',
  },
  {
    id: 3,
    name: 'RTX 4090 Super',
    specs: '24GB GDDR6X | 575W | Ada',
    price: 39990000,
    originalPrice: null,
    badge: 'NEW',
    discount: 0,
    icon: '🎮',
  },
  {
    id: 4,
    name: 'RTX 4080 Super',
    specs: '16GB GDDR6X | 320W',
    price: 19990000,
    originalPrice: 26990000,
    badge: 'HOT',
    discount: 26,
    icon: '🎮',
  },
  {
    id: 5,
    name: 'Corsair Vengeance 64GB DDR5',
    specs: '6000MHz | CL30 | RGB',
    price: 5990000,
    originalPrice: 8990000,
    badge: 'SALE',
    discount: 33,
    icon: '🎚️',
  },
  {
    id: 6,
    name: 'Kingston Fury 32GB DDR4',
    specs: '3600MHz | CL18 | RGB',
    price: 2990000,
    originalPrice: 3990000,
    badge: 'SALE',
    discount: 25,
    icon: '🎚️',
  },
  {
    id: 7,
    name: 'ASUS ROG STRIX Z890-E',
    specs: 'LGA1700 | PCIe 5.0 | WiFi 7',
    price: 4990000,
    originalPrice: 6990000,
    badge: 'NEW',
    discount: 0,
    icon: '🖥️',
  },
  {
    id: 8,
    name: 'Corsair RM1000x Gold',
    specs: '1000W | 80+ Gold | Modular',
    price: 3490000,
    originalPrice: 4990000,
    badge: 'HOT',
    discount: 30,
    icon: '⚡',
  },
]
</script>

<style scoped>
.line-clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
</style>
