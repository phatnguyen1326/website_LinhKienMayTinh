<template>
  <section class="bg-[#0D0F12] py-12">
    <div class="max-w-7xl mx-auto px-4">
      <h2 class="text-3xl font-bold text-[#F1F5F9] mb-8">Danh Mục Sản Phẩm</h2>

      <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div
          v-for="category in categories"
          :key="category.id"
          class="card-hover group p-6 text-center cursor-pointer"
        >
          <div class="text-5xl mb-4 group-hover:scale-110 transition-transform duration-300">
            {{ category.icon }}
          </div>
          <h3 class="font-semibold text-[#F1F5F9] mb-2">{{ category.name }}</h3>
          <p class="text-xs text-[#94A3B8]">{{ category.count }} sản phẩm</p>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
const categories = [
  {
    id: 'ram',
    name: 'RAM',
    icon: '🎚️',
    count: 245,
  },
  {
    id: 'cpu',
    name: 'Vi Xử Lý',
    icon: '⚙️',
    count: 189,
  },
  {
    id: 'vga',
    name: 'Card Màn Hình',
    icon: '🎮',
    count: 156,
  },
  {
    id: 'mainboard',
    name: 'Mainboard',
    icon: '🖥️',
    count: 134,
  },
  {
    id: 'psu',
    name: 'Nguồn Máy Tính',
    icon: '⚡',
    count: 98,
  },
  {
    id: 'case',
    name: 'Vỏ Case',
    icon: '📦',
    count: 112,
  },
]
</script>
