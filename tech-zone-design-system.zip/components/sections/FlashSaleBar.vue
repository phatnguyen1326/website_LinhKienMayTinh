<template>
  <section class="bg-[#EF4444] py-8">
    <div class="max-w-7xl mx-auto px-4">
      <!-- Timer and title -->
      <div class="flex items-center justify-between mb-6">
        <div>
          <h2 class="text-2xl md:text-3xl font-bold text-white mb-1">Flash Sale</h2>
          <p class="text-white/80 text-sm">Ưu đãi khiếp đảo, thời gian có hạn!</p>
        </div>

        <!-- Countdown timer -->
        <div class="flex items-center gap-2 bg-black/30 px-6 py-3 rounded-lg">
          <div class="text-center">
            <div class="text-3xl font-bold text-white">{{ String(hours).padStart(2, '0') }}</div>
            <div class="text-xs text-white/70">Giờ</div>
          </div>
          <div class="text-2xl text-white font-bold">:</div>
          <div class="text-center">
            <div class="text-3xl font-bold text-white">{{ String(minutes).padStart(2, '0') }}</div>
            <div class="text-xs text-white/70">Phút</div>
          </div>
          <div class="text-2xl text-white font-bold">:</div>
          <div class="text-center">
            <div class="text-3xl font-bold text-white">{{ String(seconds).padStart(2, '0') }}</div>
            <div class="text-xs text-white/70">Giây</div>
          </div>
        </div>
      </div>

      <!-- Horizontal scroll products -->
      <div class="overflow-x-auto scrollbar-hide">
        <div class="flex gap-4 pb-2">
          <div
            v-for="product in saleProducts"
            :key="product.id"
            class="flex-shrink-0 w-64 card hover:border-[#2563EB] transition-colors"
          >
            <!-- Product image placeholder -->
            <div class="h-40 bg-gradient-to-br from-[#1E2228] to-[#0D0F12] rounded-lg mb-4 flex items-center justify-center">
              <div class="text-4xl">{{ product.icon }}</div>
            </div>

            <!-- Product info -->
            <div class="flex-1">
              <div class="flex gap-2 mb-2">
                <span class="badge-sale">-{{ product.discount }}%</span>
              </div>
              <h3 class="font-semibold text-[#F1F5F9] mb-1 line-clamp-2">{{ product.name }}</h3>
              <p class="text-xs text-[#94A3B8] mb-3">{{ product.specs }}</p>

              <!-- Pricing -->
              <div class="mb-3">
                <p class="text-sm text-[#94A3B8] line-through">{{ product.originalPrice.toLocaleString('vi-VN') }}₫</p>
                <p class="text-lg font-bold text-[#EF4444]">{{ product.salePrice.toLocaleString('vi-VN') }}₫</p>
              </div>

              <!-- Actions -->
              <div class="flex gap-2">
                <button class="flex-1 btn-primary text-sm">
                  Mua
                </button>
                <button class="px-3 py-2 border border-[rgba(255,255,255,0.1)] rounded-lg text-[#F1F5F9] hover:border-[#2563EB] transition-colors">
                  💙
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'

const hours = ref(2)
const minutes = ref(30)
const seconds = ref(45)

const saleProducts = [
  {
    id: 1,
    name: 'Intel Core i9-14900K',
    specs: '24 nhân | LGA1700 | 125W',
    originalPrice: 24990000,
    salePrice: 17990000,
    discount: 28,
    icon: '⚙️',
  },
  {
    id: 2,
    name: 'RTX 4080 Super',
    specs: '16GB GDDR6X | 320W | Founders',
    originalPrice: 26990000,
    salePrice: 19990000,
    discount: 26,
    icon: '🎮',
  },
  {
    id: 3,
    name: 'Corsair Vengeance 64GB DDR5',
    specs: '6000MHz | CL30 | RGB',
    originalPrice: 8990000,
    salePrice: 5990000,
    discount: 33,
    icon: '🎚️',
  },
  {
    id: 4,
    name: 'ASUS ROG STRIX Z890-E',
    specs: 'LGA1700 | PCIe 5.0 | WiFi 7',
    originalPrice: 6990000,
    salePrice: 4990000,
    discount: 29,
    icon: '🖥️',
  },
  {
    id: 5,
    name: 'Corsair RM1000x Gold',
    specs: '1000W | 80+ Gold | Modular',
    originalPrice: 4990000,
    salePrice: 3490000,
    discount: 30,
    icon: '⚡',
  },
  {
    id: 6,
    name: 'Lian Li O11 XL',
    specs: 'Tempered Glass | Dual Chamber',
    originalPrice: 2990000,
    salePrice: 1990000,
    discount: 33,
    icon: '📦',
  },
]

// Timer logic
let timerInterval: NodeJS.Timeout | null = null

onMounted(() => {
  timerInterval = setInterval(() => {
    if (seconds.value > 0) {
      seconds.value--
    } else if (minutes.value > 0) {
      minutes.value--
      seconds.value = 59
    } else if (hours.value > 0) {
      hours.value--
      minutes.value = 59
      seconds.value = 59
    } else {
      // Reset timer when it reaches 00:00:00
      hours.value = 2
      minutes.value = 30
      seconds.value = 45
    }
  }, 1000)
})

onUnmounted(() => {
  if (timerInterval) clearInterval(timerInterval)
})
</script>

<style scoped>
.scrollbar-hide {
  -ms-overflow-style: none;
  scrollbar-width: none;
}

.scrollbar-hide::-webkit-scrollbar {
  display: none;
}

.line-clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
</style>
