<template>
  <section class="bg-[#0D0F12] py-12">
    <div class="max-w-7xl mx-auto px-4">
      <!-- Recently Viewed -->
      <div v-if="recentlyViewed.length > 0" class="mb-16">
        <h2 class="text-2xl font-bold text-[#F1F5F9] mb-6">Đã Xem Gần Đây</h2>
        <div class="overflow-x-auto scrollbar-hide">
          <div class="flex gap-4 pb-2">
            <div
              v-for="product in recentlyViewed"
              :key="product.id"
              class="flex-shrink-0 w-48 card hover:border-[#2563EB] transition-colors"
            >
              <div class="h-32 bg-gradient-to-br from-[#1E2228] to-[#0D0F12] rounded-lg mb-3 flex items-center justify-center">
                <div class="text-3xl">{{ product.icon }}</div>
              </div>
              <h3 class="font-semibold text-[#F1F5F9] mb-1 text-sm line-clamp-2">{{ product.name }}</h3>
              <p class="text-lg font-bold text-[#2563EB]">{{ product.price.toLocaleString('vi-VN') }}₫</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Brand Logos -->
      <div>
        <h2 class="text-2xl font-bold text-[#F1F5F9] mb-8">Các Thương Hiệu Uy Tín</h2>
        <div class="overflow-x-auto scrollbar-hide">
          <div class="flex gap-6 pb-2 justify-between md:justify-start">
            <div
              v-for="brand in brands"
              :key="brand.id"
              class="flex-shrink-0 w-40 h-32 card flex items-center justify-center group cursor-pointer hover:border-[#2563EB] transition-colors"
            >
              <div class="text-center">
                <div class="text-4xl mb-2 group-hover:scale-110 transition-transform">{{ brand.icon }}</div>
                <p class="text-[#94A3B8] text-sm font-medium">{{ brand.name }}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
const recentlyViewed = [
  {
    id: 1,
    name: 'Intel Core i9-14900K',
    price: 17990000,
    icon: '⚙️',
  },
  {
    id: 2,
    name: 'RTX 4080 Super',
    price: 19990000,
    icon: '🎮',
  },
  {
    id: 3,
    name: 'Corsair Vengeance 64GB',
    price: 5990000,
    icon: '🎚️',
  },
]

const brands = [
  {
    id: 1,
    name: 'Intel',
    icon: '🔷',
  },
  {
    id: 2,
    name: 'AMD',
    icon: '🔶',
  },
  {
    id: 3,
    name: 'NVIDIA',
    icon: '💚',
  },
  {
    id: 4,
    name: 'ASUS',
    icon: '⚫',
  },
  {
    id: 5,
    name: 'MSI',
    icon: '🔴',
  },
  {
    id: 6,
    name: 'Corsair',
    icon: '⚪',
  },
  {
    id: 7,
    name: 'Kingston',
    icon: '🟦',
  },
  {
    id: 8,
    name: 'Gigabyte',
    icon: '🟫',
  },
]
</script>

<style scoped>
.scrollbar-hide {
  -ms-overflow-style: none;
  scrollbar-width: none;
}

.scrollbar-hide::-webkit-scrollbar {
  display: none;
}

.line-clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
</style>
