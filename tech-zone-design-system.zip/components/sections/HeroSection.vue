<template>
  <section class="relative w-full min-h-[600px] bg-[#0D0F12] overflow-hidden flex items-center">
    <!-- Animated particle background -->
    <div class="absolute inset-0 overflow-hidden">
      <svg class="w-full h-full opacity-20" viewBox="0 0 1200 600">
        <defs>
          <pattern id="circuit" patternUnits="userSpaceOnUse" width="100" height="100">
            <circle cx="25" cy="25" r="2" fill="#2563EB" opacity="0.5" />
            <circle cx="75" cy="75" r="2" fill="#06B6D4" opacity="0.5" />
            <line x1="25" y1="25" x2="75" y2="75" stroke="#2563EB" stroke-width="0.5" opacity="0.3" />
          </pattern>
        </defs>
        <rect width="1200" height="600" fill="url(#circuit)" />
      </svg>
    </div>

    <!-- Content -->
    <div class="relative z-10 max-w-7xl mx-auto px-4 w-full">
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <!-- Left: Text Content -->
        <div>
          <h1 class="text-5xl md:text-6xl font-bold text-[#F1F5F9] mb-4">
            Linh Kiện Máy Tính
            <span class="bg-gradient-to-r from-[#2563EB] via-[#06B6D4] to-[#2563EB] bg-clip-text text-transparent">
              Chính Hãng
            </span>
          </h1>
          <p class="text-lg text-[#94A3B8] mb-2 leading-relaxed">
            RAM | CPU | VGA | Mainboard | Nguồn | Case — Bảo hành 36 tháng
          </p>
          <p class="text-[#94A3B8] mb-8 leading-relaxed">
            Những linh kiện PC chất lượng cao với giá cạnh tranh. Xây dựng PC gaming hoặc workstation của bạn ngay hôm nay.
          </p>

          <div class="flex gap-4">
            <button class="btn-primary">
              Mua ngay
            </button>
            <button class="btn-secondary">
              Xem khuyến mãi
            </button>
          </div>
        </div>

        <!-- Right: Floating Product Placeholder -->
        <div class="hidden lg:flex justify-center items-center">
          <div class="relative w-64 h-64">
            <!-- Glow effect -->
            <div class="absolute inset-0 bg-gradient-to-br from-[#2563EB]/30 to-[#06B6D4]/30 rounded-xl blur-2xl" />

            <!-- Card -->
            <div class="relative card p-8 flex flex-col items-center justify-center transform hover:scale-105 transition-transform duration-300">
              <div class="w-48 h-48 bg-gradient-to-br from-[#2563EB]/20 to-[#06B6D4]/20 rounded-lg flex items-center justify-center mb-4">
                <svg class="w-32 h-32 text-[#2563EB]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M6 9l6-7 8 8v8a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V9z" />
                  <circle cx="13" cy="13" r="2" fill="currentColor" />
                </svg>
              </div>
              <p class="text-[#94A3B8] text-sm text-center">Premium GPU Card</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
// Hero section component
</script>

<style scoped>
@keyframes float {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-20px);
  }
}

.animate-float {
  animation: float 3s ease-in-out infinite;
}
</style>
