<template>
  <section class="bg-gradient-to-r from-[#161A1F] to-[#0D0F12] py-12 border-y border-[rgba(255,255,255,0.08)]">
    <div class="max-w-7xl mx-auto px-4">
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        <div v-for="item in whyChooseUs" :key="item.id" class="flex flex-col items-center text-center">
          <div class="text-5xl mb-4">{{ item.icon }}</div>
          <h3 class="text-lg font-semibold text-[#F1F5F9] mb-2">{{ item.title }}</h3>
          <p class="text-[#94A3B8] text-sm">{{ item.description }}</p>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
const whyChooseUs = [
  {
    id: 1,
    icon: '✅',
    title: 'Chính Hãng 100%',
    description: 'Tất cả sản phẩm đều được kiểm chứng chính hãng từ nhà sản xuất',
  },
  {
    id: 2,
    icon: '🛡️',
    title: 'Bảo Hành 36 Tháng',
    description: 'Bảo hành toàn bộ từ 1 đến 3 năm tùy theo sản phẩm',
  },
  {
    id: 3,
    icon: '🚚',
    title: 'Giao Hàng Toàn Quốc',
    description: 'Giao nhanh 24-48 giờ tại Hà Nội, TP.HCM & giao đến toàn quốc',
  },
  {
    id: 4,
    icon: '📞',
    title: 'Hỗ Trợ 24/7',
    description: 'Đội ngũ hỗ trợ khách hàng sẵn sàng giúp đỡ mọi lúc',
  },
]
</script>
