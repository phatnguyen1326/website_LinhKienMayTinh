import { defineNuxtConfig } from 'nuxt/config'

export default defineNuxtConfig({
  compatibilityDate: '2024-04-03',
  devtools: { enabled: false },

  modules: [
    '@nuxtjs/tailwindcss',
  ],

  vite: {
    server: {
      allowedHosts: [
        'localhost',
        '127.0.0.1',
        'sb-7g74pg5shlxi.vercel.run',
        '.vercel.run',
      ],
      hmr: {
        host: 'sb-7g74pg5shlxi.vercel.run',
        port: 443,
        protocol: 'wss',
      },
    },
    ssr: {
      external: ['node:crypto'],
    },
    optimizeDeps: {
      exclude: ['@nuxt/devtools'],
    },
  },

  css: ['~/assets/css/tailwind.css'],

  imports: { autoImport: true },

  components: { auto: true },

  image: { provider: 'ipx' },

  tailwindcss: { cssPath: false },
})
