import { defineStore } from 'pinia'

export interface CartItem {
  id: string
  productId: string
  name: string
  price: number
  quantity: number
  image: string
  specs?: Record<string, string>
}

interface CartState {
  items: CartItem[]
}

export const useCartStore = defineStore('cart', {
  state: (): CartState => ({
    items: [],
  }),

  getters: {
    cartCount: (state) => state.items.length,
    
    totalPrice: (state) => 
      state.items.reduce((total, item) => total + (item.price * item.quantity), 0),

    cartItems: (state) => state.items,
  },

  actions: {
    addItem(item: CartItem) {
      const existingItem = this.items.find(i => i.productId === item.productId)
      if (existingItem) {
        existingItem.quantity += item.quantity
      } else {
        this.items.push(item)
      }
    },

    removeItem(productId: string) {
      this.items = this.items.filter(item => item.productId !== productId)
    },

    updateQuantity(productId: string, quantity: number) {
      const item = this.items.find(i => i.productId === productId)
      if (item) {
        item.quantity = quantity
      }
    },

    clearCart() {
      this.items = []
    },
  },
})
