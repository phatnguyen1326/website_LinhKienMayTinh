import { defineStore } from 'pinia'

export interface Product {
  id: string
  slug: string
  name: string
  category: string
  brand: string
  price: number
  originalPrice: number
  discount: number
  rating: number
  reviews: number
  image: string
  gallery: string[]
  description: string
  specs: Record<string, string>
  stock: number
  warranty: string
  badges: string[]
}

interface ProductFilter {
  category?: string
  brand?: string
  priceMin?: number
  priceMax?: number
  inStock?: boolean
  searchQuery?: string
}

interface ProductState {
  products: Product[]
  filters: ProductFilter
  currentProduct: Product | null
}

export const useProductStore = defineStore('product', {
  state: (): ProductState => ({
    products: [],
    filters: {},
    currentProduct: null,
  }),

  getters: {
    filteredProducts: (state) => {
      return state.products.filter(product => {
        if (state.filters.category && product.category !== state.filters.category) return false
        if (state.filters.brand && product.brand !== state.filters.brand) return false
        if (state.filters.priceMin && product.price < state.filters.priceMin) return false
        if (state.filters.priceMax && product.price > state.filters.priceMax) return false
        if (state.filters.inStock && product.stock === 0) return false
        if (state.filters.searchQuery) {
          const query = state.filters.searchQuery.toLowerCase()
          return product.name.toLowerCase().includes(query) || 
                 product.description.toLowerCase().includes(query)
        }
        return true
      })
    },

    getProductBySlug: (state) => (slug: string) => {
      return state.products.find(p => p.slug === slug)
    },

    categories: (state) => [...new Set(state.products.map(p => p.category))],
    brands: (state) => [...new Set(state.products.map(p => p.brand))],
  },

  actions: {
    setProducts(products: Product[]) {
      this.products = products
    },

    setFilter(filter: ProductFilter) {
      this.filters = { ...this.filters, ...filter }
    },

    clearFilters() {
      this.filters = {}
    },

    setCurrentProduct(product: Product | null) {
      this.currentProduct = product
    },
  },
})
