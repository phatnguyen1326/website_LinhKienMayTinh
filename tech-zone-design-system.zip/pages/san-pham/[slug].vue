<template>
  <div class="min-h-screen bg-[#0D0F12] py-8">
    <div class="max-w-7xl mx-auto px-4">
      <!-- Breadcrumb -->
      <div class="mb-8 flex items-center gap-2 text-sm">
        <NuxtLink to="/" class="text-[#06B6D4] hover:text-[#2563EB]">Trang chủ</NuxtLink>
        <span class="text-[#94A3B8]">/</span>
        <NuxtLink to="/san-pham" class="text-[#06B6D4] hover:text-[#2563EB]">Sản phẩm</NuxtLink>
        <span class="text-[#94A3B8]">/</span>
        <span class="text-[#F1F5F9]">{{ product?.name }}</span>
      </div>

      <div v-if="product" class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Left Column: Gallery -->
        <div class="lg:col-span-1">
          <ProductGallery :product="product" />
        </div>

        <!-- Middle Column: Product Info -->
        <div class="lg:col-span-1">
          <!-- Brand & Title -->
          <div class="mb-4">
            <span class="text-[#06B6D4] font-semibold text-sm">{{ product.brand }}</span>
            <h1 class="text-2xl font-bold text-[#F1F5F9] mb-2">{{ product.name }}</h1>
          </div>

          <!-- Rating -->
          <div class="flex items-center gap-4 mb-6 pb-6 border-b border-[rgba(255,255,255,0.08)]">
            <div class="flex items-center gap-2">
              <div class="flex">
                <span v-for="i in 5" :key="i" class="text-yellow-400">
                  {{ i <= Math.floor(product.rating) ? '★' : '☆' }}
                </span>
              </div>
              <span class="text-[#94A3B8]">{{ product.rating }}/5</span>
            </div>
            <span class="text-[#94A3B8] text-sm">({{ product.reviews }} đánh giá)</span>
          </div>

          <!-- Pricing -->
          <div class="mb-6 pb-6 border-b border-[rgba(255,255,255,0.08)]">
            <div class="flex items-center gap-3 mb-2">
              <span class="text-4xl font-bold text-[#2563EB]">
                {{ formatPrice(product.price) }}
              </span>
              <span v-if="product.originalPrice > product.price" class="text-lg text-[#94A3B8] line-through">
                {{ formatPrice(product.originalPrice) }}
              </span>
            </div>
            <div class="flex items-center gap-2">
              <span class="badge-sale">
                -{{ product.discount }}%
              </span>
              <span class="text-[#94A3B8] text-sm">
                Tiết kiệm {{ formatPrice(product.originalPrice - product.price) }}
              </span>
            </div>
          </div>

          <!-- Installment Options -->
          <div class="mb-6 pb-6 border-b border-[rgba(255,255,255,0.08)]">
            <h3 class="text-[#F1F5F9] font-semibold mb-3">Opsi Cicilan (0% APR)</h3>
            <div class="space-y-2">
              <div class="flex items-center justify-between px-3 py-2 bg-[#161A1F] rounded text-sm">
                <span class="text-[#94A3B8]">3 tháng</span>
                <span class="text-[#F1F5F9] font-semibold">{{ formatPrice(product.price / 3) }}/tháng</span>
              </div>
              <div class="flex items-center justify-between px-3 py-2 bg-[#161A1F] rounded text-sm">
                <span class="text-[#94A3B8]">6 tháng</span>
                <span class="text-[#F1F5F9] font-semibold">{{ formatPrice(product.price / 6) }}/tháng</span>
              </div>
              <div class="flex items-center justify-between px-3 py-2 bg-[#161A1F] rounded text-sm">
                <span class="text-[#94A3B8]">12 tháng</span>
                <span class="text-[#F1F5F9] font-semibold">{{ formatPrice(product.price / 12) }}/tháng</span>
              </div>
            </div>
          </div>

          <!-- Quantity & Actions -->
          <div class="space-y-3">
            <div class="flex items-center gap-4">
              <span class="text-[#94A3B8] text-sm">Số lượng:</span>
              <div class="flex items-center bg-[#161A1F] rounded">
                <button @click="quantity = Math.max(1, quantity - 1)" class="px-3 py-1 text-[#94A3B8] hover:text-[#F1F5F9]">−</button>
                <span class="px-4 text-[#F1F5F9]">{{ quantity }}</span>
                <button @click="quantity++" :disabled="quantity >= product.stock" class="px-3 py-1 text-[#94A3B8] hover:text-[#F1F5F9] disabled:opacity-50">+</button>
              </div>
            </div>

            <button 
              @click="addToCart"
              :disabled="product.stock === 0"
              class="w-full btn-primary py-3 disabled:opacity-50"
            >
              {{ product.stock > 0 ? 'Thêm Vào Giỏ Hàng' : 'Hết Hàng' }}
            </button>

            <div class="flex gap-2">
              <button class="flex-1 btn-secondary py-2">❤ Yêu Thích</button>
              <button class="flex-1 btn-secondary py-2">📊 So Sánh</button>
            </div>
          </div>
        </div>

        <!-- Right Column: Additional Info -->
        <div class="lg:col-span-1 space-y-4">
          <!-- Shipping Info -->
          <div class="bg-[#161A1F] rounded-lg p-4">
            <h3 class="text-[#F1F5F9] font-semibold mb-3 text-sm">Vận Chuyển</h3>
            <div class="space-y-2 text-sm text-[#94A3B8]">
              <p>✓ Giao hàng miễn phí từ 500K</p>
              <p>✓ Giao trong 24 giờ (Hà Nội, HCM)</p>
              <p>✓ Đổi trả trong 30 ngày</p>
            </div>
          </div>

          <!-- Support Info -->
          <div class="bg-[#161A1F] rounded-lg p-4">
            <h3 class="text-[#F1F5F9] font-semibold mb-3 text-sm">Hỗ Trợ</h3>
            <div class="space-y-2 text-sm text-[#94A3B8]">
              <p>📞 Hotline: 1800-xxxx</p>
              <p>💬 Chat: 9h - 22h (Hàng ngày)</p>
              <p>✉️ Email: support@techzone.vn</p>
            </div>
          </div>

          <!-- Payment Methods -->
          <div class="bg-[#161A1F] rounded-lg p-4">
            <h3 class="text-[#F1F5F9] font-semibold mb-3 text-sm">Thanh Toán</h3>
            <div class="flex gap-2">
              <span class="text-2xl">💳</span>
              <span class="text-2xl">📱</span>
              <span class="text-2xl">🏦</span>
              <span class="text-2xl">💰</span>
            </div>
          </div>

          <!-- Seller Info -->
          <div class="bg-[#161A1F] rounded-lg p-4">
            <div class="flex items-start gap-3 mb-3">
              <div class="w-10 h-10 bg-[#2563EB] rounded-full flex items-center justify-center text-white font-bold">T</div>
              <div>
                <p class="text-[#F1F5F9] font-semibold text-sm">TechZone Official</p>
                <p class="text-[#94A3B8] text-xs">✓ Người bán uy tín</p>
              </div>
            </div>
            <button class="w-full btn-secondary text-sm py-2">Xem Cửa Hàng</button>
          </div>
        </div>
      </div>

      <!-- Product Tabs -->
      <div v-if="product" class="mt-12">
        <div class="flex gap-4 border-b border-[rgba(255,255,255,0.08)] mb-6">
          <button
            v-for="tab in tabs"
            :key="tab"
            @click="activeTab = tab"
            class="px-4 py-2 font-semibold transition"
            :class="activeTab === tab 
              ? 'text-[#2563EB] border-b-2 border-[#2563EB]' 
              : 'text-[#94A3B8] hover:text-[#F1F5F9]'"
          >
            {{ tab }}
          </button>
        </div>

        <!-- Tab Content -->
        <div v-if="activeTab === 'Chi Tiết'" class="bg-[#161A1F] rounded-lg p-6">
          <ProductSpecs :product="product" />
        </div>

        <div v-else-if="activeTab === 'Mô Tả'" class="bg-[#161A1F] rounded-lg p-6">
          <p class="text-[#94A3B8] leading-relaxed">{{ product.description }}</p>
        </div>

        <div v-else-if="activeTab === 'Đánh Giá'" class="bg-[#161A1F] rounded-lg p-6">
          <p class="text-[#94A3B8]">{{ product.reviews }} đánh giá từ khách hàng</p>
        </div>
      </div>

      <!-- Related Products -->
      <div class="mt-12">
        <h2 class="text-2xl font-bold text-[#F1F5F9] mb-6">Sản Phẩm Tương Tự</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <ProductCard 
            v-for="relatedProduct in relatedProducts.slice(0, 4)"
            :key="relatedProduct.id"
            :product="relatedProduct"
          />
        </div>
      </div>
    </div>

    <!-- TechBot Widget -->
    <TechBotWidget />
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useProductStore } from '~/stores/product'
import { useCartStore } from '~/stores/cart'
import { mockProducts } from '~/utils/mockData'

definePageMeta({
  layout: 'default',
})

const route = useRoute()
const productStore = useProductStore()
const cartStore = useCartStore()

const quantity = ref(1)
const activeTab = ref('Chi Tiết')
const tabs = ['Chi Tiết', 'Mô Tả', 'Đánh Giá']

const product = computed(() => {
  return mockProducts.find(p => p.slug === route.params.slug)
})

const relatedProducts = computed(() => {
  return mockProducts.filter(p => p.category === product.value?.category && p.id !== product.value?.id)
})

const formatPrice = (price: number) => {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
  }).format(price)
}

const addToCart = () => {
  if (product.value) {
    cartStore.addItem({
      id: `${product.value.id}-${Date.now()}`,
      productId: product.value.id,
      name: product.value.name,
      price: product.value.price,
      quantity: quantity.value,
      image: product.value.image,
    })
    quantity.value = 1
  }
}
</script>
