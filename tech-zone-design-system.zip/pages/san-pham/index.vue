<template>
  <div class="min-h-screen bg-[#0D0F12] py-8">
    <div class="max-w-7xl mx-auto px-4">
      <!-- Breadcrumb -->
      <div class="mb-8 flex items-center gap-2 text-sm">
        <NuxtLink to="/" class="text-[#06B6D4] hover:text-[#2563EB]">Trang chủ</NuxtLink>
        <span class="text-[#94A3B8]">/</span>
        <span class="text-[#F1F5F9]">Sản phẩm</span>
      </div>

      <!-- Header -->
      <div class="mb-8">
        <h1 class="text-4xl font-bold text-[#F1F5F9] mb-2">Danh Sách Sản Phẩm</h1>
        <p class="text-[#94A3B8]">{{ paginatedProducts.length }} sản phẩm trong {{ totalPages }} trang</p>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <!-- Sidebar Filter -->
        <div class="lg:col-span-1">
          <ProductFilter />
        </div>

        <!-- Main Content -->
        <div class="lg:col-span-3">
          <!-- Active Filters Bar -->
          <div v-if="activeFilters.length > 0" class="mb-6 flex flex-wrap gap-2">
            <div 
              v-for="filter in activeFilters"
              :key="`${filter.type}-${filter.value}`"
              class="badge-secondary flex items-center gap-2"
            >
              <span>{{ filter.value }}</span>
              <button 
                @click="removeFilter(filter.type, filter.value)"
                class="hover:opacity-70"
              >
                ✕
              </button>
            </div>
          </div>

          <!-- Sort and View Options -->
          <div class="mb-6 flex items-center justify-between gap-4">
            <div class="flex items-center gap-2">
              <label class="text-[#94A3B8] text-sm">Sắp xếp:</label>
              <select
                v-model="sortBy"
                class="bg-[#161A1F] border border-[rgba(255,255,255,0.08)] rounded px-3 py-2 text-[#F1F5F9] text-sm focus:outline-none focus:border-[#2563EB]"
              >
                <option value="popular">Phổ biến</option>
                <option value="price">Giá: Thấp → Cao</option>
                <option value="newest">Mới nhất</option>
              </select>
            </div>

            <div class="flex items-center gap-2">
              <button
                @click="viewMode = 'grid'"
                class="px-3 py-2 rounded transition"
                :class="viewMode === 'grid' ? 'bg-[#2563EB] text-white' : 'bg-[#161A1F] text-[#94A3B8]'"
              >
                ⊞
              </button>
              <button
                @click="viewMode = 'list'"
                class="px-3 py-2 rounded transition"
                :class="viewMode === 'list' ? 'bg-[#2563EB] text-white' : 'bg-[#161A1F] text-[#94A3B8]'"
              >
                ≡
              </button>
            </div>
          </div>

          <!-- Products Grid/List -->
          <div 
            v-if="paginatedProducts.length > 0"
            :class="viewMode === 'grid' 
              ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' 
              : 'space-y-4'"
          >
            <ProductCard 
              v-for="product in paginatedProducts"
              :key="product.id"
              :product="product"
              @compare="handleCompare"
            />
          </div>

          <!-- No Results -->
          <div v-else class="text-center py-12">
            <p class="text-[#94A3B8] mb-4">Không tìm thấy sản phẩm phù hợp</p>
            <button 
              @click="productStore.clearFilters()"
              class="btn-primary"
            >
              Xóa Bộ Lọc
            </button>
          </div>

          <!-- Pagination -->
          <div v-if="totalPages > 1" class="mt-12 flex items-center justify-center gap-2">
            <button
              @click="currentPage = Math.max(1, currentPage - 1)"
              :disabled="currentPage === 1"
              class="px-3 py-2 rounded bg-[#161A1F] text-[#94A3B8] disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#1E2228] transition"
            >
              ← Trước
            </button>

            <div class="flex gap-1">
              <button
                v-for="page in Math.min(totalPages, 5)"
                :key="page"
                @click="currentPage = page"
                class="px-3 py-2 rounded transition"
                :class="currentPage === page 
                  ? 'bg-[#2563EB] text-white' 
                  : 'bg-[#161A1F] text-[#94A3B8] hover:bg-[#1E2228]'"
              >
                {{ page }}
              </button>
            </div>

            <button
              @click="currentPage = Math.min(totalPages, currentPage + 1)"
              :disabled="currentPage === totalPages"
              class="px-3 py-2 rounded bg-[#161A1F] text-[#94A3B8] disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#1E2228] transition"
            >
              Sau →
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- TechBot Widget -->
    <TechBotWidget />
  </div>
</template>

<script setup lang="ts">
import { useProductStore } from '~/stores/product'
import { useProductFilter } from '~/composables/useProductFilter'
import { mockProducts } from '~/utils/mockData'

definePageMeta({
  layout: 'default',
})

const productStore = useProductStore()
const {
  sortBy,
  viewMode,
  currentPage,
  activeFilters,
  paginatedProducts,
  totalPages,
  removeFilter,
} = useProductFilter()

onMounted(() => {
  productStore.setProducts(mockProducts)
})

const handleCompare = (productId: string) => {
  console.log('Compare product:', productId)
}
</script>
