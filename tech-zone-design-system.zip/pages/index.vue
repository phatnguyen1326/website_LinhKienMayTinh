<template>
  <div class="bg-[#0D0F12]">
    <!-- Hero Section -->
    <HeroSection />

    <!-- Flash Sale Bar -->
    <FlashSaleBar />

    <!-- Category Grid -->
    <div class="py-12">
      <CategoryGrid />
    </div>

    <!-- Featured Products -->
    <FeaturedProducts />

    <!-- Why Choose Us -->
    <WhyChooseUs />

    <!-- Recently Viewed + Brands -->
    <div class="py-12">
      <BrandLogos />
    </div>

    <!-- TechBot Widget -->
    <TechBotWidget />
  </div>
</template>

<script setup lang="ts">
import HeroSection from '~/components/sections/HeroSection.vue'
import FlashSaleBar from '~/components/sections/FlashSaleBar.vue'
import CategoryGrid from '~/components/sections/CategoryGrid.vue'
import FeaturedProducts from '~/components/sections/FeaturedProducts.vue'
import WhyChooseUs from '~/components/sections/WhyChooseUs.vue'
import BrandLogos from '~/components/sections/BrandLogos.vue'
import TechBotWidget from '~/components/ai/TechBotWidget.vue'

definePageMeta({
  layout: 'default',
})
</script>


