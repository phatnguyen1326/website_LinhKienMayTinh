# TechZone - E-Commerce PC Parts Store

A modern Vietnamese e-commerce platform for PC components built with Nuxt 3, Vue 3 Composition API, Pinia, and Tailwind CSS.

## Project Structure

```
ecommerce-ai-portfolio/
├── components/
│   ├── layout/
│   │   ├── AppNavbar.vue          # Main navigation bar with search and icons
│   │   ├── AppFooter.vue          # Footer with links, payment, and social
│   │   └── AnnouncementBar.vue    # Top announcement with promo message
│   ├── product/
│   │   ├── ProductCard.vue        # Product card component for listings
│   │   ├── ProductGallery.vue     # Product image gallery with thumbnails
│   │   ├── ProductFilter.vue      # Sidebar filter component
│   │   └── ProductSpecs.vue       # Product specifications table
│   ├── ai/
│   │   └── TechBotWidget.vue      # AI chatbot widget powered by Gemini
│   ├── sections/
│   │   ├── HeroSection.vue        # Homepage hero banner
│   │   ├── FlashSaleBar.vue       # Flash sale countdown section
│   │   ├── FeaturedProducts.vue   # Featured products grid
│   │   ├── CategoryGrid.vue       # Category showcase
│   │   ├── WhyChooseUs.vue        # USP cards section
│   │   └── BrandLogos.vue         # Partner brands carousel
│   └── icons/
│       ├── IconCPU.vue            # CPU icon
│       ├── IconSearch.vue         # Search icon
│       ├── IconCart.vue           # Shopping cart icon
│       ├── IconUser.vue           # User account icon
│       ├── IconCompare.vue        # Compare icon
│       └── IconChevronDown.vue    # Dropdown chevron
├── pages/
│   ├── index.vue                  # Homepage
│   └── san-pham/
│       ├── index.vue              # Product listing page
│       └── [slug].vue             # Product detail page
├── stores/
│   ├── cart.ts                    # Pinia store for shopping cart
│   └── product.ts                 # Pinia store for products & filters
├── composables/
│   └── useProductFilter.ts        # Composable for filtering/sorting
├── utils/
│   └── mockData.ts                # Mock product data
├── layouts/
│   └── default.vue                # Default layout wrapper
├── assets/
│   └── css/
│       └── tailwind.css           # Tailwind styles
├── nuxt.config.ts                 # Nuxt configuration
├── tailwind.config.ts             # Tailwind CSS configuration
├── postcss.config.mjs             # PostCSS configuration
└── tsconfig.json                  # TypeScript configuration
```

## Features

### 🎨 Design
- **Dark Tech Aesthetic**: Professional dark theme with electric blue (#2563EB) and cyan (#06B6D4) accents
- **Responsive Design**: Mobile-first approach with breakpoints for all devices
- **Modern UI**: Glass morphism effects, smooth transitions, and hover animations
- **Vietnamese Localization**: Full Vietnamese language support

### 🛍️ E-Commerce Features
- **Product Listing** (`/san-pham`): 
  - Grid/List view toggle
  - Advanced filtering (category, brand, price range, stock status)
  - Sorting (popular, price, newest)
  - Active filters display with removal options
  - Pagination (12 products per page)

- **Product Details** (`/san-pham/[slug]`):
  - Image gallery with thumbnails
  - Product specifications table
  - Customer rating and reviews count
  - Installment options (3, 6, 12 months @ 0% APR)
  - Stock status display
  - Quantity selector
  - Related products carousel
  - Tabbed content (specs, description, reviews)

### 🛒 Shopping Cart
- Add/remove items from cart
- Update quantities
- Real-time cart total calculation
- Persistent state with Pinia

### 🤖 AI Features
- **TechBot Widget**: Floating AI chatbot for customer support
- Quick question chips for common inquiries
- Powered by Gemini AI (placeholder implementation)
- Available on all pages

### 📦 Product Management
- 8 main categories: RAM, CPU, VGA, Mainboard, Nguồn (PSU), Case
- Multiple brands (Intel, AMD, NVIDIA, Corsair, ASUS, Samsung, NZXT)
- Mock data with 48+ products
- Product badges (Chính hãng, HOT, BÁN CHẠY, NEW)
- Comprehensive product specifications

### 💳 Payment & Shipping
- Multiple payment methods: Visa, MoMo, VNPAY, PayPal
- Free shipping for orders over 500K VND
- 24-hour delivery in Hà Nội & TP.HCM
- 30-day return policy
- Multiple installment plans

## Tech Stack

### Frontend Framework
- **Nuxt 3.21.5** - Vue 3 meta-framework with server-side rendering
- **Vue 3** - Composition API for reactive components
- **TypeScript** - Type-safe development

### State Management
- **Pinia 3.0.4** - Official state management library for Vue 3
- Stores: `useCartStore`, `useProductStore`

### Styling
- **Tailwind CSS 3.4.0** - Utility-first CSS framework
- **PostCSS** - CSS preprocessing
- Dark theme with custom color palette

### Dev Tools
- **Vite 7.3.3** - Lightning-fast build tool
- **DevTools** - Vue DevTools integration

## Color Palette

| Element | Color | Hex |
|---------|-------|-----|
| Background | Near Black | #0D0F12 |
| Surface | Dark | #161A1F |
| Primary | Electric Blue | #2563EB |
| Secondary | Cyan | #06B6D4 |
| Danger | Red | #EF4444 |
| Success | Green | #22C55E |
| Text Primary | White | #F1F5F9 |
| Text Secondary | Gray | #94A3B8 |

## Getting Started

### Prerequisites
- Node.js 16+ and pnpm or npm

### Installation
```bash
cd ecommerce-ai-portfolio
pnpm install
```

### Development
```bash
pnpm dev
```
Server runs on `http://localhost:3000` (or next available port)

### Build for Production
```bash
pnpm build
```

### Preview Production Build
```bash
pnpm preview
```

## Key Components

### Stores (Pinia)

#### `useCartStore()`
```typescript
- addItem(item: CartItem)
- removeItem(productId: string)
- updateQuantity(productId: string, quantity: number)
- clearCart()
- Getters: cartCount, totalPrice, cartItems
```

#### `useProductStore()`
```typescript
- setProducts(products: Product[])
- setFilter(filter: ProductFilter)
- clearFilters()
- setCurrentProduct(product: Product | null)
- Getters: filteredProducts, categories, brands, getProductBySlug
```

### Composables

#### `useProductFilter()`
```typescript
Reactive filtering and sorting with computed properties:
- sortBy: 'price' | 'newest' | 'popular'
- viewMode: 'grid' | 'list'
- currentPage, activeFilters
- paginatedProducts, totalPages
- removeFilter(type, value)
```

## Routes

| Route | Component | Purpose |
|-------|-----------|---------|
| `/` | `pages/index.vue` | Homepage with hero, flash sales, featured products |
| `/san-pham` | `pages/san-pham/index.vue` | Product listing with filters |
| `/san-pham/[slug]` | `pages/san-pham/[slug].vue` | Product detail page |

## Mock Data

8 sample products included:
- Intel Core i9-14900K (CPU)
- AMD Ryzen 9 7900X3D (CPU)
- Corsair Vengeance RGB 32GB (RAM)
- NVIDIA RTX 4090 (VGA)
- ASUS ROG STRIX Z690-E (Mainboard)
- Corsair RM1000x Gold (PSU)
- NZXT H7 Flow RGB (Case)
- Samsung 980 PRO 2TB (Storage)

Each product includes: specifications, gallery images, pricing, ratings, stock status, warranty, and badges.

## Development Guidelines

### Component Organization
- Functional components using Vue 3 Composition API with `<script setup>`
- Type-safe with TypeScript interfaces
- Props and emits explicitly defined
- Computed properties for reactive data

### Naming Conventions
- Components: PascalCase (ProductCard.vue)
- Files: kebab-case (product-card.vue)
- Stores: useStoreName (useCartStore)
- Composables: useComposableName (useProductFilter)

### Styling
- Use Tailwind utility classes
- Avoid inline styles
- Follow dark theme color palette
- Responsive design with `md:`, `lg:` prefixes

## Future Enhancements

- [ ] Real database integration (PostgreSQL)
- [ ] User authentication & accounts
- [ ] Wishlist functionality
- [ ] Product reviews & ratings system
- [ ] Search engine optimization (SEO)
- [ ] Admin dashboard for product management
- [ ] Real Gemini AI integration for TechBot
- [ ] Order management system
- [ ] Payment gateway integration (Stripe, VNPay)
- [ ] Email notifications
- [ ] Multi-language support beyond Vietnamese

## Browser Support

- Chrome/Chromium (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Performance

- Static site generation with Nuxt 3
- Image optimization with Nuxt Image
- Lazy loading for product images
- Efficient Pinia state management
- Tailwind CSS purging for optimized bundle

## License

MIT - Free for personal and commercial use

## Support

For questions or issues, contact: support@techzone.vn
