/// <reference types="@nuxtjs/tailwindcss" />
/// <reference types="@nuxt/telemetry" />
/// <reference path="types/nitro-layouts.d.ts" />
/// <reference path="types/builder-env.d.ts" />
/// <reference types="nuxt" />
/// <reference path="types/app-defaults.d.ts" />
/// <reference path="types/plugins.d.ts" />
/// <reference path="types/build.d.ts" />
/// <reference path="types/schema.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference path="../node_modules/.pnpm/@nuxt+vite-builder@3.21.5_@types+node@22.19.11_lightningcss@1.31.1_magicast@0.5.2_nuxt@_214b25e2f926a2a9e3c5e13fbab2e97d/node_modules/@nuxt/vite-builder/dist/index.d.mts" />
/// <reference path="../node_modules/.pnpm/@nuxt+nitro-server@3.21.5_db0@0.3.4_ioredis@5.10.1_magicast@0.5.2_nuxt@3.21.5_@parcel+w_ecf239bc404d25d6bc25d27ae966dde7/node_modules/@nuxt/nitro-server/dist/index.d.mts" />
/// <reference types="vue-router" />
/// <reference path="types/middleware.d.ts" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="types/layouts.d.ts" />
/// <reference path="types/components.d.ts" />
/// <reference path="imports.d.ts" />
/// <reference path="types/imports.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />
/// <reference path="types/nitro.d.ts" />

export {}
