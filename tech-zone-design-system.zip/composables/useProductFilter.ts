import { ref, computed } from 'vue'
import { useProductStore, type Product } from '~/stores/product'

export function useProductFilter() {
  const productStore = useProductStore()
  
  const sortBy = ref<'price' | 'newest' | 'popular'>('popular')
  const viewMode = ref<'grid' | 'list'>('grid')
  const currentPage = ref(1)
  const itemsPerPage = ref(12)

  const activeFilters = computed(() => {
    const filters = []
    if (productStore.filters.category) filters.push({ type: 'category', value: productStore.filters.category })
    if (productStore.filters.brand) filters.push({ type: 'brand', value: productStore.filters.brand })
    if (productStore.filters.priceMin || productStore.filters.priceMax) {
      filters.push({ 
        type: 'price', 
        value: `${productStore.filters.priceMin || 0} - ${productStore.filters.priceMax || 50000000}` 
      })
    }
    if (productStore.filters.searchQuery) filters.push({ type: 'search', value: productStore.filters.searchQuery })
    return filters
  })

  const sortedProducts = computed(() => {
    const products = [...productStore.filteredProducts]
    
    switch (sortBy.value) {
      case 'price':
        return products.sort((a, b) => a.price - b.price)
      case 'newest':
        return products.reverse()
      case 'popular':
        return products.sort((a, b) => b.rating - a.rating)
      default:
        return products
    }
  })

  const paginatedProducts = computed(() => {
    const start = (currentPage.value - 1) * itemsPerPage.value
    const end = start + itemsPerPage.value
    return sortedProducts.value.slice(start, end)
  })

  const totalPages = computed(() => Math.ceil(sortedProducts.value.length / itemsPerPage.value))

  const removeFilter = (type: string, value: string) => {
    switch (type) {
      case 'category':
        productStore.setFilter({ category: undefined })
        break
      case 'brand':
        productStore.setFilter({ brand: undefined })
        break
      case 'price':
        productStore.setFilter({ priceMin: undefined, priceMax: undefined })
        break
      case 'search':
        productStore.setFilter({ searchQuery: undefined })
        break
    }
  }

  return {
    sortBy,
    viewMode,
    currentPage,
    activeFilters,
    sortedProducts,
    paginatedProducts,
    totalPages,
    removeFilter,
  }
}
