<template>
  <div class="flex flex-col min-h-screen bg-[#0D0F12] text-[#F1F5F9]">
    <!-- Top Announcement -->
    <TopAnnouncement />

    <!-- Main Navbar -->
    <Navbar />

    <!-- Category Menu -->
    <CategoryMegaMenu />

    <!-- Main Content -->
    <main class="flex-1">
      <slot />
    </main>

    <!-- Footer -->
    <Footer />
  </div>
</template>

<script setup lang="ts">
import TopAnnouncement from '~/components/layout/TopAnnouncement.vue'
import Navbar from '~/components/layout/Navbar.vue'
import CategoryMegaMenu from '~/components/layout/CategoryMegaMenu.vue'
import Footer from '~/components/layout/Footer.vue'
</script>
